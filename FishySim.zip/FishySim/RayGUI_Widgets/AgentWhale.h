#pragma once
class Whale
{
};

